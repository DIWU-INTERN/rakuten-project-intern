# config/initializers/rakuten.rb
RakutenWebService.configure do |c|
  c.application_id = ENV['RAKUTEN_APP_ID']
end

